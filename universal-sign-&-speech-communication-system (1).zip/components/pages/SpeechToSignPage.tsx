import React, { useState, useEffect, useContext, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LanguageContext } from '../../contexts/LanguageContext';
import { CustomSignsContext } from '../../contexts/CustomSignsContext';
import { translateText } from '../../services/translationService';
import { ASL_ALPHABET } from '../../constants';
import { Sign } from '../../types'; // Import Sign type

// Lucide React Icons (as SVG paths to avoid external dependencies)
const MicIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" x2="12" y1="19" y2="22"></line></svg>);
const RotateCwIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 2v6h-6"></path><path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path><path d="M3 22v-6h6"></path><path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path></svg>);

// Add type for SpeechRecognition API for cross-browser compatibility
interface SpeechRecognitionStatic {
    new(): SpeechRecognition;
}

interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    start(): void;
    stop(): void;
    onresult: (event: any) => void;
    onerror: (event: any) => void;
    onend: () => void;
    // Optional properties, might be needed for full compatibility/advanced features
    onaudiostart?: () => void;
    onsoundstart?: () => void;
    onspeechstart?: () => void;
    onspeechend?: () => void;
    onsoundend?: () => void;
    onaudioend?: () => void;
    onnomatch?: () => void;
    onstart?: () => void;
    onstop?: () => void;
}

declare global {
    interface Window {
        SpeechRecognition: SpeechRecognitionStatic;
        webkitSpeechRecognition: SpeechRecognitionStatic;
    }
}

// A mock for SpeechRecognition for environments where it's not supported
const mockSpeechRecognition: SpeechRecognition = {
    continuous: false,
    interimResults: false,
    lang: '',
    start: () => {console.warn('SpeechRecognition not supported, using mock.');},
    stop: () => {console.warn('SpeechRecognition not supported, using mock.');},
    onresult: (event: any) => {},
    onerror: (event: any) => {},
    onend: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
};

const SpeechToSignPage: React.FC = () => {
    const [isListening, setIsListening] = useState(false);
    const [recognizedText, setRecognizedText] = useState(''); // Text from speech recognition
    const [displayedText, setDisplayedText] = useState(''); // Text shown in the output box (might be translated)
    const [signImages, setSignImages] = useState<string[]>([]); // URLs for ASL letters
    const [customSignWord, setCustomSignWord] = useState<string | null>(null); // For custom signs (textual)
    const [recognitionError, setRecognitionError] = useState<string | null>(null);
    const [translationError, setTranslationError] = useState<string | null>(null);

    const recognitionRef = useRef<SpeechRecognition | null>(null);
    const { language } = useContext(LanguageContext);
    const { customSigns } = useContext(CustomSignsContext); // customSigns are now Sign[]

    const processTextForSigns = useCallback(async (text: string) => {
        setSignImages([]); // Clear previous signs
        setCustomSignWord(null); // Clear custom sign
        setTranslationError(null); // Clear previous translation errors

        const trimmedText = text.trim();
        if (!trimmedText) {
            return;
        }

        let textToMatch = trimmedText;

        // If the current language is not English, translate to English for ASL alphabet mapping
        if (language.code !== 'en') {
            try {
                const translatedResult = await translateText(trimmedText, {code: 'en', name: 'English'});
                if (translatedResult.startsWith('[Translation Failed')) {
                    setTranslationError(translatedResult);
                    // Fallback to original text if translation fails
                } else {
                    textToMatch = translatedResult;
                }
            } catch (error: any) {
                console.error("Error translating text for ASL matching:", error);
                setTranslationError(`Translation to English failed: ${error.message || 'Unknown error'}.`);
                // Fallback to original text
            }
        }
        
        // First, check for custom signs (case-insensitive match)
        // Now customSigns is an array of Sign objects, so we access `s.word`
        const matchedCustomSign = customSigns.find(s => s.word.toLowerCase() === textToMatch.toLowerCase());
        if (matchedCustomSign) {
            setCustomSignWord(matchedCustomSign.word); // Store the word from the matched Sign object
        } else {
            // If no custom sign, break into characters for ASL alphabet
            const words = textToMatch.toUpperCase().split(/\s+/).filter(Boolean); // Split by space and remove empty strings
            const chars: string[] = [];
            words.forEach(word => {
                for (const char of word) {
                    if (ASL_ALPHABET[char]) {
                        chars.push(ASL_ALPHABET[char]);
                    }
                }
            });
            setSignImages(chars);
        }
    }, [customSigns, language.code]); // customSigns added to dependencies

    useEffect(() => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            setRecognitionError('Speech Recognition API is not supported in this browser. Please use Chrome for full functionality.');
            recognitionRef.current = mockSpeechRecognition;
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.continuous = false; // Only get one result per recognition start
        recognition.interimResults = false; // Only return final results
        recognition.lang = language.code; // Set recognition language based on settings

        recognition.onresult = async (event) => {
            setRecognitionError(null);
            const transcript = event.results[0][0].transcript;
            setRecognizedText(transcript);
            setDisplayedText(transcript); // Show original recognized text immediately
            processTextForSigns(transcript);
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error', event.error);
            setRecognitionError(`Speech recognition error: ${event.error}. Please try again. Ensure microphone permissions are granted.`);
            setIsListening(false);
        };

        recognition.onend = () => {
            setIsListening(false);
        };

        recognitionRef.current = recognition;

        return () => {
            recognitionRef.current?.stop();
        };
    }, [language, processTextForSigns]); // Re-run effect if language or processing logic changes
    
    const handleListen = () => {
        if (recognitionRef.current === mockSpeechRecognition) {
            setRecognitionError('Speech Recognition API is not supported in this browser.');
            return;
        }

        if (isListening) {
            recognitionRef.current?.stop();
            setIsListening(false);
        } else {
            setRecognizedText('');
            setDisplayedText('');
            setSignImages([]);
            setCustomSignWord(null);
            setRecognitionError(null); // Clear previous errors
            setTranslationError(null);
            
            try {
                recognitionRef.current?.start();
                setIsListening(true);
            } catch (error: any) {
                console.error("Error starting speech recognition:", error);
                setRecognitionError(`Could not start speech recognition: ${error.message || 'Unknown error'}. Ensure microphone permissions are granted.`);
                setIsListening(false);
            }
        }
    };
    
    const replaySigns = useCallback(() => {
        if(!recognizedText) return;
        processTextForSigns(recognizedText);
    }, [recognizedText, processTextForSigns]);

    return (
        <motion.div 
            className="flex flex-col items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <motion.div 
                className="w-full max-w-4xl bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                aria-live="polite"
            >
                <h2 className="text-3xl font-bold text-cyan-400 mb-6 text-center">Speech-to-Sign</h2>
                
                <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-8">
                    <motion.button
                        onClick={handleListen}
                        className={`flex items-center justify-center gap-3 w-56 py-3 px-4 rounded-lg font-semibold text-white transition-all duration-300 text-lg ${
                            isListening ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-cyan-500 hover:bg-cyan-600'
                        }`}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        disabled={recognitionRef.current === mockSpeechRecognition}
                        aria-label={isListening ? 'Stop listening' : 'Start listening'}
                    >
                        <MicIcon className="w-6 h-6" />
                        <span>{isListening ? 'Listening...' : 'Start Listening'}</span>
                    </motion.button>
                    <motion.button
                        onClick={replaySigns}
                        disabled={!recognizedText || isListening}
                        className="flex items-center justify-center gap-3 w-56 py-3 px-4 rounded-lg font-semibold text-white bg-purple-500 hover:bg-purple-600 transition-all duration-300 disabled:bg-gray-600 disabled:cursor-not-allowed text-lg"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        aria-label="Replay sign visuals"
                    >
                        <RotateCwIcon className="w-6 h-6" />
                        <span>Replay Signs</span>
                    </motion.button>
                </div>
                
                {(recognitionError || translationError) && (
                    <motion.p 
                        className="text-red-400 text-base mt-4 mb-4 p-3 bg-red-900/30 rounded-md text-center"
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        role="alert"
                    >
                        {recognitionError || translationError}
                    </motion.p>
                )}

                <motion.div 
                    className="bg-gray-900/50 p-6 rounded-lg min-h-[6rem] text-center mb-6 border border-gray-700"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    aria-label="Recognized text output"
                >
                    <p className="text-gray-400 text-base mb-2">Recognized Text ({language.name}):</p>
                    <motion.p 
                        key={displayedText}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className="text-3xl text-white font-mono"
                    >
                        {displayedText || 'Speak into your microphone...'}
                    </motion.p>
                </motion.div>
                
                <motion.div 
                    className="bg-gray-900/50 p-6 rounded-lg min-h-[12rem] flex items-center justify-center border border-gray-700"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    aria-label="Sign language visuals"
                >
                    {customSignWord ? (
                        <motion.div 
                            className="text-center"
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ type: "spring", stiffness: 200, damping: 20 }}
                        >
                             <p className="text-gray-400 text-lg mb-3">Custom Sign:</p>
                             <div className="bg-white/10 p-6 rounded-xl border border-white/20 shadow-md">
                                 <span className="text-5xl font-bold text-cyan-300 font-mono">{customSignWord}</span>
                             </div>
                         </motion.div>
                    ) : signImages.length > 0 ? (
                        <div className="flex flex-wrap gap-4 justify-center">
                            <AnimatePresence>
                                {signImages.map((src, index) => (
                                    <motion.div 
                                        key={index} 
                                        className="bg-white/10 p-3 rounded-lg border border-white/20 shadow-sm"
                                        initial={{ opacity: 0, scale: 0.5 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        exit={{ opacity: 0, scale: 0.5 }}
                                        transition={{ delay: index * 0.05, type: "spring", stiffness: 300, damping: 20 }}
                                    >
                                        <img src={src} alt={`sign for letter ${String.fromCharCode(65 + index)}`} className="h-28 w-28 object-contain" />
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>
                    ) : (
                        <p className="text-gray-500 text-lg">Sign language visuals will appear here</p>
                    )}
                </motion.div>
            </motion.div>
        </motion.div>
    );
};

export { SpeechToSignPage };