import React from 'react';
import { motion } from 'framer-motion';

// Lucide React Icons (as SVG paths to avoid external dependencies)
const CameraIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path><circle cx="12" cy="13" r="3"></circle></svg>);
const MicIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" x2="12" y1="19" y2="22"></line></svg>);
const GlobeIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"></circle><line x1="2" x2="22" y1="12" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>);


const FeatureCard: React.FC<{ title: string; description: string, icon: React.ReactNode, delay: number }> = ({ title, description, icon, delay }) => (
    <motion.div 
        className="bg-white/10 backdrop-blur-md p-6 rounded-xl border border-white/20 shadow-lg relative overflow-hidden group"
        whileHover={{ 
            scale: 1.05, 
            borderColor: 'rgba(6, 182, 212, 0.5)', 
            boxShadow: '0 0 30px rgba(6, 182, 212, 0.3)',
            transition: { type: "spring", stiffness: 300, damping: 15 }
        }}
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: delay }}
    >
        <motion.div 
            className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"
            />
        <div className="relative z-10">
            <div className="flex items-center justify-center w-12 h-12 bg-cyan-500/20 rounded-lg mb-4">
                {icon}
            </div>
            <h3 className="text-xl font-bold text-cyan-400 mb-2">{title}</h3>
            <p className="text-gray-300">{description}</p>
        </div>
    </motion.div>
);

const HomePage: React.FC = () => {
    return (
        <motion.div 
            className="relative overflow-hidden rounded-xl py-12 bg-white/5 backdrop-blur-md border border-white/20 shadow-lg text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
        >
            {/* Animated background element */}
            <motion.div
                className="absolute -inset-x-96 -inset-y-96 z-0 bg-gradient-to-br from-cyan-900/40 to-purple-900/40 rounded-full blur-3xl opacity-50"
                initial={{ scale: 0.5, rotate: 0, x: -200, y: -200 }}
                animate={{ 
                    scale: [0.5, 1.2, 0.8, 0.5], 
                    rotate: [0, 90, 180, 270, 360],
                    x: [-200, 100, -50, 200, -200],
                    y: [-200, -50, 100, -100, -200]
                }}
                transition={{ duration: 45, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.h1 
                className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-500 relative z-10" /* Increased mb-4 to mb-6 */
                initial={{ opacity: 0, y: -50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
            >
                Universal Sign & Speech
            </motion.h1>
            <motion.p 
                className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto mb-16 relative z-10" /* Increased mb-12 to mb-16 */
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
            >
                Breaking barriers and fostering inclusion by bridging the communication gap between sign language and spoken language communities.
            </motion.p>
            <div className="grid md:grid-cols-3 gap-8 relative z-10 px-8"> {/* Added horizontal padding */}
                <FeatureCard 
                    title="Sign-to-Speech" 
                    description="Use your webcam to translate sign language into spoken words in real-time. Our AI understands your gestures and speaks them aloud."
                    icon={<CameraIcon className="w-6 h-6 text-cyan-400" />}
                    delay={0.4}
                />
                <FeatureCard 
                    title="Speech-to-Sign" 
                    description="Speak into your microphone, and our system will display the corresponding sign language gestures, making conversations accessible to all."
                    icon={<MicIcon className="w-6 h-6 text-cyan-400" />}
                    delay={0.6}
                />
                <FeatureCard 
                    title="Multi-Language Support" 
                    description="Communicate globally with built-in translation. Convert signs and speech to and from various languages seamlessly."
                    icon={<GlobeIcon className="w-6 h-6 text-cyan-400" />}
                    delay={0.8}
                />
            </div>
        </motion.div>
    );
};

export { HomePage };