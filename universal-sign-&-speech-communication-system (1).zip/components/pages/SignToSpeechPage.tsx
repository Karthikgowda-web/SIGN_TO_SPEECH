import React, { useState, useRef, useEffect, useCallback, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { translateText } from '../../services/translationService';
import { LanguageContext } from '../../contexts/LanguageContext';
import { CustomSignsContext } from '../../contexts/CustomSignsContext';
import { MOCKED_SIGNS } from '../../constants';
import { Sign } from '../../types'; // Import Sign type

// Lucide React Icons (as SVG paths to avoid external dependencies)
const CameraIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path><circle cx="12" cy="13" r="3"></circle></svg>);
const Volume2Icon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>);
const PlayIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>);
const StopCircleIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"></circle><rect width="6" height="6" x="9" y="9"></rect></svg>);
const SpeechIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21.5 5.5V17a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8.5L2 11"></path><path d="M19 19a2 2 0 0 1-2 2H5c-1.7 0-3-1-3-2V8.5L2 11"></path><path d="M10 13l2 2 4-4"></path></svg>);


const LoadingSpinner: React.FC = () => (
    <motion.div
        className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"
        initial={{ rotate: 0 }}
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
    ></motion.div>
);

const SignToSpeechPage: React.FC = () => {
    const [isDetecting, setIsDetecting] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [recognizedText, setRecognizedText] = useState('');
    const [spokenText, setSpokenText] = useState('');
    const [confidence, setConfidence] = useState(0);
    const [status, setStatus] = useState('Idle');
    const [cameraError, setCameraError] = useState('');
    const [translationError, setTranslationError] = useState('');
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const detectionIntervalRef = useRef<number | null>(null);

    const { language } = useContext(LanguageContext);
    const { customSigns } = useContext(CustomSignsContext); // customSigns are now Sign[]
    
    // TTS state
    const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
    const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
    const [rate, setRate] = useState(1);
    const [pitch, setPitch] = useState(1);
    const [volume, setVolume] = useState(1);
    
    // Load voices and select default based on language code
    useEffect(() => {
        const loadVoices = () => {
            const availableVoices = window.speechSynthesis.getVoices();
            if (availableVoices.length > 0) {
                setVoices(availableVoices);
                // Try to find a voice matching the current language code, otherwise default to the first one.
                const newSelectedVoice = availableVoices.find(v => v.lang.startsWith(language.code)) || availableVoices[0];
                setSelectedVoice(newSelectedVoice);
            }
        };

        // Ensure voices are loaded even if onvoiceschanged doesn't fire immediately
        loadVoices(); 
        window.speechSynthesis.onvoiceschanged = loadVoices;

        return () => {
            stopDetection();
            window.speechSynthesis.onvoiceschanged = null; // Clean up event listener
            window.speechSynthesis.cancel(); // Stop any ongoing speech
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [language.code]); // Re-run when language code changes to update default voice
    
    const speak = useCallback((text: string) => {
        if (!text || !selectedVoice) return;
        window.speechSynthesis.cancel(); // Stop any current speech to prioritize new one
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang; // Use the selected voice's language
        utterance.rate = rate;
        utterance.pitch = pitch;
        utterance.volume = volume;
        utterance.onstart = () => setStatus('Speaking...');
        utterance.onend = () => {
            // Only revert to 'Detecting...' if detection is still active
            setStatus(isDetecting ? 'Detecting...' : 'Idle'); 
        };
        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event.error);
            setStatus(`Speech Error: ${event.error}`);
        };
        window.speechSynthesis.speak(utterance);
    }, [selectedVoice, rate, pitch, volume, isDetecting]);

    const startDetection = async () => {
        setIsLoading(true);
        setStatus('Initializing...');
        setCameraError('');
        setTranslationError('');
        setRecognizedText('');
        setSpokenText('');
        setConfidence(0);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                videoRef.current.play();
            }
            setIsDetecting(true);
            setIsLoading(false); // Finished loading

            setStatus('Detecting...'); // Set status after successful initialization
            
            detectionIntervalRef.current = window.setInterval(async () => {
                // Combine mocked signs (strings) and custom signs (objects, extract word)
                const allSignWords = [...MOCKED_SIGNS, ...customSigns.map(s => s.word)];

                if (allSignWords.length === 0) {
                    setRecognizedText('No signs configured!');
                    setSpokenText('');
                    setConfidence(0);
                    setStatus('No signs available for detection.');
                    return;
                }

                // Mock detection: In a real app, this would involve sending video frames to a ML model
                // and receiving a prediction.
                const detectedSignWord = allSignWords[Math.floor(Math.random() * allSignWords.length)];
                setRecognizedText(detectedSignWord);
                const newConfidence = Math.random() * (0.99 - 0.7) + 0.7; // Realistic confidence range
                setConfidence(newConfidence);
                setStatus('Sign detected: ' + detectedSignWord);
                
                let translatedText = '';
                try {
                    const result = await translateText(detectedSignWord, language);
                    if (result.startsWith('[Translation Failed')) {
                        setTranslationError(result);
                        translatedText = detectedSignWord; // Fallback to original if translation fails
                    } else {
                        setTranslationError('');
                        translatedText = result;
                    }
                } catch (err: any) {
                    console.error('Error during translation:', err);
                    setTranslationError(`Translation failed: ${err.message || 'Unknown error'}.`);
                    translatedText = detectedSignWord; // Fallback
                }
                
                setSpokenText(translatedText);
                speak(translatedText);

            }, 3000); // Detect every 3 seconds

        } catch (err: any) {
            console.error("Error accessing webcam:", err);
            setCameraError(`Webcam Error: ${err.name || 'Unknown'}: ${err.message || 'Permission denied or device unavailable.'} Please ensure camera permissions are granted.`);
            setStatus('Error: Webcam access denied.');
            setIsDetecting(false); // Ensure detection is off if camera fails
            setIsLoading(false);
        }
    };

    const stopDetection = () => {
        if (detectionIntervalRef.current) {
            clearInterval(detectionIntervalRef.current);
            detectionIntervalRef.current = null;
        }
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            videoRef.current.srcObject = null;
        }
        setIsDetecting(false);
        setRecognizedText('');
        setSpokenText('');
        setConfidence(0);
        setStatus('Idle');
        setCameraError('');
        setTranslationError('');
        window.speechSynthesis.cancel(); // Stop any ongoing speech
    };

    const handleToggleDetection = () => {
        if (isDetecting) {
            stopDetection();
        } else {
            startDetection();
        }
    };
    
    return (
        <motion.div 
            className="grid md:grid-cols-2 gap-8 items-start"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            {/* Left Column: Camera and Controls */}
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                aria-live="polite"
            >
                <h2 className="text-3xl font-bold text-cyan-400 mb-6 flex items-center gap-3"><CameraIcon className="w-8 h-8"/> Sign-to-Speech</h2>
                <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative flex items-center justify-center border border-gray-700">
                    <video ref={videoRef} className={`w-full h-full object-cover ${isDetecting ? '' : 'hidden'}`} muted aria-label="Webcam feed for sign detection" />
                    <AnimatePresence>
                        {(!isDetecting || isLoading) && (
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/80 text-gray-400"
                            >
                                {isLoading ? (
                                    <>
                                        <LoadingSpinner />
                                        <p className="mt-4 text-xl" aria-label="Loading camera and model">Loading camera & model...</p>
                                    </>
                                ) : (
                                    <>
                                        <CameraIcon className="w-16 h-16 mb-4 text-gray-500" aria-hidden="true" />
                                        <p className="text-xl">Camera is off</p>
                                    </>
                                )}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
                {cameraError && (
                    <motion.p 
                        className="text-red-400 text-base mt-4 p-3 bg-red-900/30 rounded-md"
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        role="alert"
                    >
                        {cameraError}
                    </motion.p>
                )}
                <motion.button
                    onClick={handleToggleDetection}
                    className={`mt-6 w-full py-3 px-4 rounded-lg font-semibold text-white transition-all duration-300 flex items-center justify-center gap-3 text-lg
                        ${isDetecting ? 'bg-red-500 hover:bg-red-600' : 'bg-cyan-500 hover:bg-cyan-600'}
                        ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    disabled={isLoading}
                    aria-label={isDetecting ? 'Stop sign detection' : 'Start sign detection'}
                >
                    {isLoading ? (
                        <>
                            <LoadingSpinner />
                            <span>Starting...</span>
                        </>
                    ) : isDetecting ? (
                        <>
                            <StopCircleIcon className="w-6 h-6" />
                            <span>Stop Detection</span>
                        </>
                    ) : (
                        <>
                            <PlayIcon className="w-6 h-6" />
                            <span>Start Detection</span>
                        </>
                    )}
                </motion.button>

                {/* TTS Controls */}
                <div className="mt-8 p-6 bg-gray-900/50 rounded-xl border border-gray-700">
                    <h3 className="text-xl font-bold text-gray-300 mb-4 flex items-center gap-2"><Volume2Icon className="w-6 h-6" aria-hidden="true"/> Speech Output Settings</h3>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="voice-select" className="block text-base font-medium text-gray-400 mb-2">Voice</label>
                            <select
                                id="voice-select"
                                value={selectedVoice?.name || ''}
                                onChange={(e) => setSelectedVoice(voices.find(v => v.name === e.target.value) || null)}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white text-base focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200"
                                aria-label="Select speech synthesis voice"
                            >
                                {voices.length === 0 && <option value="">Loading voices...</option>}
                                {voices.map(voice => (
                                    <option key={voice.name} value={voice.name}>
                                        {voice.name} ({voice.lang}) {voice.default ? '[Default]' : ''}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="rate-slider" className="block text-base font-medium text-gray-400 mb-2">Rate ({rate.toFixed(1)})</label>
                            <input
                                id="rate-slider"
                                type="range"
                                min="0.5"
                                max="2"
                                step="0.1"
                                value={rate}
                                onChange={(e) => setRate(parseFloat(e.target.value))}
                                className="w-full h-3 bg-gray-600 rounded-lg appearance-none cursor-pointer range-sm accent-cyan-500"
                                aria-valuenow={rate}
                                aria-valuemin={0.5}
                                aria-valuemax={2}
                                aria-label={`Speech rate, current value ${rate.toFixed(1)}`}
                            />
                        </div>
                        <div>
                            <label htmlFor="pitch-slider" className="block text-base font-medium text-gray-400 mb-2">Pitch ({pitch.toFixed(1)})</label>
                            <input
                                id="pitch-slider"
                                type="range"
                                min="0"
                                max="2"
                                step="0.1"
                                value={pitch}
                                onChange={(e) => setPitch(parseFloat(e.target.value))}
                                className="w-full h-3 bg-gray-600 rounded-lg appearance-none cursor-pointer range-sm accent-cyan-500"
                                aria-valuenow={pitch}
                                aria-valuemin={0}
                                aria-valuemax={2}
                                aria-label={`Speech pitch, current value ${pitch.toFixed(1)}`}
                            />
                        </div>
                        <div>
                            <label htmlFor="volume-slider" className="block text-base font-medium text-gray-400 mb-2">Volume ({volume.toFixed(1)})</label>
                            <input
                                id="volume-slider"
                                type="range"
                                min="0"
                                max="1"
                                step="0.1"
                                value={volume}
                                onChange={(e) => setVolume(parseFloat(e.target.value))}
                                className="w-full h-3 bg-gray-600 rounded-lg appearance-none cursor-pointer range-sm accent-cyan-500"
                                aria-valuenow={volume}
                                aria-valuemin={0}
                                aria-valuemax={1}
                                aria-label={`Speech volume, current value ${volume.toFixed(1)}`}
                            />
                        </div>
                    </div>
                </div>
            </motion.div>

            {/* Right Column: Real-time Feedback */}
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ x: 100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                aria-live="polite"
            >
                <h3 className="text-3xl font-bold text-purple-400 mb-6">Real-time Feedback</h3>
                <div className="space-y-4">
                    <FeedbackCard label="Current Recognized Sign" value={recognizedText || 'N/A'} delay={0.1} icon={<CameraIcon className="w-5 h-5 text-purple-400"/>} />
                    <FeedbackCard label="Confidence Score" value={confidence > 0 ? `${(confidence * 100).toFixed(1)}%` : 'N/A'} delay={0.2} icon={<SpeechIcon className="w-5 h-5 text-purple-400"/>} />
                    <FeedbackCard label="Current Output Language" value={language.name} delay={0.3} icon={<Volume2Icon className="w-5 h-5 text-purple-400"/>} />
                    <FeedbackCard label="Spoken Output" value={spokenText || 'Awaiting sign...'} delay={0.4} icon={<SpeechIcon className="w-5 h-5 text-purple-400"/>} />
                    <FeedbackCard label="Status" value={status} delay={0.5} icon={isLoading ? <LoadingSpinner /> : <StopCircleIcon className="w-5 h-5 text-purple-400"/>} />
                </div>
                {translationError && (
                    <motion.p 
                        className="text-red-400 text-base mt-4 p-3 bg-red-900/30 rounded-md"
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        role="alert"
                    >
                        {translationError}
                    </motion.p>
                )}
            </motion.div>
        </motion.div>
    );
};

interface FeedbackCardProps {
    label: string;
    value: string;
    delay: number;
    icon: React.ReactNode;
}

const FeedbackCard: React.FC<FeedbackCardProps> = ({ label, value, delay, icon }) => (
    <motion.div
        className="bg-gray-900/50 p-4 rounded-lg border border-gray-700 flex items-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: delay }}
    >
        <div className="mr-3 flex-shrink-0">
            {icon}
        </div>
        <div>
            <p className="text-gray-400 text-sm mb-1">{label}</p>
            <p className="text-white text-lg font-semibold">{value}</p>
        </div>
    </motion.div>
);

export { SignToSpeechPage };