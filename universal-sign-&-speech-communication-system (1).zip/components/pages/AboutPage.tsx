import React from 'react';
import { motion } from 'framer-motion';

const sectionVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 }
};

const listItemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 }
};

// Lucide React Icons (as SVG paths to avoid external dependencies)
const InfoIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="16" y2="12"></line><line x1="12" x2="12.01" y1="8" y2="8"></line></svg>);


const AboutPage: React.FC = () => {
    return (
        <motion.div 
            className="max-w-4xl mx-auto text-left"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
            >
                <h2 className="text-4xl font-bold text-cyan-400 mb-8 text-center flex items-center justify-center gap-3"><InfoIcon className="w-9 h-9"/> About UniSign</h2> {/* Increased mb-6 to mb-8 */}
                
                <motion.section 
                    className="mb-8"
                    variants={sectionVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.6, delay: 0.2 }}
                >
                    <h3 className="text-2xl font-semibold text-purple-400 mb-3">Our Mission</h3>
                    <p className="text-gray-300 leading-relaxed text-base"> {/* Added text-base */}
                        Our mission is to create a more inclusive world by leveraging technology to break down communication barriers. The Universal Sign & Speech Communication System is designed to be an intuitive bridge between the deaf and hard-of-hearing community and the hearing community, facilitating seamless and natural conversations for everyone, everywhere. We believe that everyone deserves the ability to express themselves and understand others, regardless of their mode of communication.
                    </p>
                </motion.section>

                <motion.section 
                    className="mb-8"
                    variants={sectionVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.6, delay: 0.4 }}
                >
                    <h3 className="text-2xl font-semibold text-purple-400 mb-3">Technology Stack</h3>
                    <p className="text-gray-300 mb-4 text-base"> {/* Added text-base */}
                        This application is built with modern, powerful web technologies to deliver a fast, reliable, and beautiful user experience.
                    </p>
                    <motion.ul 
                        className="list-disc list-inside space-y-2 text-gray-300 ml-4"
                        initial="hidden"
                        animate="visible"
                        variants={{
                            visible: {
                                transition: {
                                    staggerChildren: 0.1
                                }
                            }
                        }}
                    >
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">React & TypeScript:</span> For a robust and scalable component-based frontend, ensuring type safety and maintainability.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Tailwind CSS:</span> For rapid, utility-first styling, enabling a beautiful, responsive, and customizable design.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Framer Motion:</span> For smooth, elegant, and performant UI animations, enhancing user engagement.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Google Gemini API:</span> Powering our advanced, real-time language translation features, providing accurate and context-aware translations.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Web Speech API:</span> Enabling native browser support for both speech-to-text (recognition) and text-to-speech (synthesis) functionalities, offering a natural voice interaction.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Machine Learning (Mocked):</span> The sign detection feature currently simulates a sophisticated ML model (e.g., based on MediaPipe Hands or TensorFlow.js Handpose) trained on ASL datasets. This demonstrates the potential for real-time gesture recognition from a webcam feed.</motion.li>
                        <motion.li variants={listItemVariants} transition={{ duration: 0.4 }} className="text-base"><span className="font-semibold text-white">Node.js & Express (Backend):</span> A lightweight backend providing user authentication (login/signup) with secure password hashing and JWT for session management, interacting with an SQLite database.</motion.li>
                    </motion.ul>
                </motion.section>

                <motion.section 
                    variants={sectionVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.6, delay: 0.6 }}
                >
                    <h3 className="text-2xl font-semibold text-purple-400 mb-3">The Team</h3>
                    <p className="text-gray-300 text-base leading-relaxed"> {/* Added text-base and line height */}
                        We are a passionate team of developers and designers dedicated to using our skills for social good. This project represents our commitment to innovation, accessibility, and creating meaningful impact through technology. We believe in the power of connection and strive to build tools that foster understanding and empathy across communities.
                    </p>
                </motion.section>
            </motion.div>
        </motion.div>
    );
};

export { AboutPage };