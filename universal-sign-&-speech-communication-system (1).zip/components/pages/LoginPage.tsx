import React, { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { AuthContext } from '../../contexts/AuthContext';
import { Page } from '../../types';
import { loginUser } from '../../services/authService';

// Lucide React Icons (as SVG paths to avoid external dependencies)
const MailIcon: React.FC<{ className?: string }> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>);
const LockIcon: React.FC<{ className?: string }> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>);
const EyeIcon: React.FC<{ className?: string }> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>);
const EyeOffIcon: React.FC<{ className?: string }> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-10-7-10-7a1.17 1.17 0 0 1 1.66-1.66m6.74-6.74A10.07 10.07 0 0 1 12 4c7 0 10 7 10 7a1.17 1.17 0 0 1-1.66 1.66"></path><path d="M10.51 10.51c.31-.31.7-.58 1.1-.78"></path><path d="M15 15.01c-.3.06-.6.09-.9.09a3 3 0 0 1-3-3c0-.3.03-.6.09-.9"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg>);


const LoginPage: React.FC = () => {
    const { login, showNotification } = useContext(AuthContext);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [showPassword, setShowPassword] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        const response = await loginUser(email, password);
        setLoading(false);

        // Ensure both token and email are available from the successful response
        if (response.token && response.email && response.id) {
            // Fix: Pass the 'id' property as required by the User interface
            login({ email: response.email, token: response.token, id: response.id }); 
            // App.tsx handles navigation to Home page and showing login success notification via `login` function
        } else {
            setError(response.message || response.error || 'Login failed. Please check your credentials.');
            showNotification(response.message || response.error || 'Login failed.', 'error');
        }
    };

    return (
        <motion.div
            className="flex items-center justify-center min-h-[calc(100vh-16rem)]" 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <motion.div
                className="w-full max-w-md bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg text-center" /* Increased p-8 */
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                aria-label="Login form"
            >
                <h2 className="text-3xl font-bold text-cyan-400 mb-6">Login to UniSign</h2>
                <form onSubmit={handleSubmit} className="space-y-5"> {/* Increased space-y-4 to space-y-5 */}
                    <motion.div className="relative" whileFocus={{ scale: 1.01 }}>
                        <MailIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" aria-hidden="true" />
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 bg-gray-700 border border-gray-600 rounded-md text-white text-base focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200" /* Added text-base */
                            required
                            disabled={loading}
                            aria-label="Email address"
                            autoComplete="email"
                        />
                    </motion.div>
                    <motion.div className="relative" whileFocus={{ scale: 1.01 }}>
                        <LockIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" aria-hidden="true" />
                        <input
                            type={showPassword ? 'text' : 'password'}
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full pl-10 pr-10 py-3 bg-gray-700 border border-gray-600 rounded-md text-white text-base focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200" /* Added text-base */
                            required
                            disabled={loading}
                            aria-label="Password"
                            autoComplete="current-password"
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(prev => !prev)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white focus:outline-none"
                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                            aria-pressed={showPassword}
                        >
                            {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                        </button>
                    </motion.div>
                    {error && (
                        <motion.p
                            className="text-red-400 text-base mt-3 p-2 bg-red-900/30 rounded-md" /* Increased text size and padding */
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.3 }}
                            role="alert"
                        >
                            {error}
                        </motion.p>
                    )}
                    <motion.button
                        type="submit"
                        className="w-full py-3 px-4 rounded-lg font-semibold text-white bg-green-600 hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-2 text-lg" /* Increased text size */
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={loading}
                        aria-label="Login button"
                    >
                        {loading ? (
                            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        ) : (
                            'Login'
                        )}
                    </motion.button>
                </form>
                <motion.p
                    className="mt-6 text-gray-400 text-base" /* Added text-base */
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                >
                    Don't have an account?{' '}
                    <button
                        onClick={() => {
                            window.dispatchEvent(new CustomEvent('navigate', { detail: Page.SignUp }));
                        }}
                        className="text-cyan-400 hover:underline font-medium"
                        disabled={loading}
                        aria-label="Navigate to Sign Up page"
                    >
                        Sign Up
                    </button>
                </motion.p>
            </motion.div>
        </motion.div>
    );
};

export { LoginPage };