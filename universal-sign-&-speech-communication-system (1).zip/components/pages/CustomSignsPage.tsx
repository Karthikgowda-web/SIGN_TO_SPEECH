import React, { useState, useRef, useContext, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CustomSignsContext } from '../../contexts/CustomSignsContext';
import { AuthContext } from '../../contexts/AuthContext'; // Import AuthContext

// Lucide React Icons (as SVG paths to avoid external dependencies)
const TrashIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" x2="10" y1="11" y2="17"></line><line x1="14" x2="14" y1="11" y2="17"></line></svg>);
const CameraIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path><circle cx="12" cy="13" r="3"></circle></svg>);
const PlusSquareIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" x2="12" y1="8" y2="16"></line><line x1="8" x2="16" y1="12" y2="12"></line></svg>);
const SaveIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M19 21H5a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h10l6 6v12a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>);
const VideoIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m16 13 5.71-3.61A1 1 0 0 0 22 9.3V4.7a1 1 0 0 0-.29-.6l-5.71-3.61A1 1 0 0 0 15 1v12a1 1 0 0 0 1 1z"></path><rect x="2" y="3" width="14" height="18" rx="2" ry="2"></rect></svg>);
const LoaderCircleIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12 2v4"></path><path d="m16.2 7.8 2.9-2.9"></path><path d="M22 12h-4"></path><path d="m16.2 16.2 2.9 2.9"></path><path d="M12 22v-4"></path><path d="m7.8 16.2-2.9 2.9"></path><path d="M2 12h4"></path><path d="m7.8 7.8-2.9-2.9"></path></svg>);


const CustomSignsPage: React.FC = () => {
    const { customSigns, addSign, removeSign, refreshSigns } = useContext(CustomSignsContext);
    const { isLoggedIn, showNotification } = useContext(AuthContext); // Use AuthContext for login status and notifications
    const [newSignWord, setNewSignWord] = useState('');
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [status, setStatus] = useState('Enter a word and click "Record Sign".');
    const [cameraError, setCameraError] = useState<string | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const stopCamera = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
        setIsCameraOn(false);
        setCameraError(null);
    }, []);

    useEffect(() => {
        // Fetch signs when the component mounts or when login status changes
        if (isLoggedIn) {
            refreshSigns();
        } else {
            // If logged out, clear local signs (App.tsx also clears, but good to ensure)
            // customSigns is managed by Context, so no direct `setCustomSigns` here
        }
        return () => {
            stopCamera();
        };
    }, [isLoggedIn, refreshSigns, stopCamera]);


    const startCamera = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                videoRef.current.play();
            }
            streamRef.current = stream;
            setIsCameraOn(true);
            setCameraError(null);
            return true;
        } catch (err: any) {
            console.error("Error accessing webcam:", err);
            setCameraError(`Webcam Error: ${err.name || 'Unknown'}: ${err.message || 'Permission denied or device unavailable.'} Please ensure camera permissions are granted.`);
            return false;
        }
    };

    const handleRecord = async () => {
        if (!isLoggedIn) {
            showNotification('Please log in to add custom signs.', 'error');
            return;
        }
        if (!newSignWord.trim()) {
            setStatus('Please enter a word for the sign before recording.');
            return;
        }
        // Check for duplicates locally based on the words from backend signs
        if (customSigns.some(s => s.word.toLowerCase() === newSignWord.trim().toLowerCase())) {
            setStatus(`"${newSignWord.trim()}" has already been added as a custom sign.`);
            return;
        }
        
        setIsRecording(true);
        setStatus('Initializing camera...');
        setCameraError(null);

        if (!isCameraOn) {
            const cameraStarted = await startCamera();
            if (!cameraStarted) {
                setIsRecording(false);
                setStatus('Failed to start camera for recording.');
                return;
            }
        }
        
        setStatus('Get ready... Hold your sign for "' + newSignWord.trim() + '"');
        setTimeout(() => {
            setStatus('Recording sign... (3 seconds)');
            setTimeout(() => {
                setStatus('Recording complete! You can now save the sign.');
                setIsRecording(false);
            }, 3000); // 3 seconds of "recording"
        }, 2000); // 2 seconds to get ready
    };

    const handleSave = async () => {
        if (!isLoggedIn) {
            showNotification('Please log in to add custom signs.', 'error');
            return;
        }
        if (newSignWord.trim() && status === 'Recording complete! You can now save the sign.') {
            // `addSign` now handles the API call and refresh internally via context
            await addSign(newSignWord.trim());
            setStatus(`Sign for "${newSignWord.trim()}" saved!`);
            setNewSignWord('');
            stopCamera();
        } else if (!newSignWord.trim()) {
            setStatus('Cannot save an empty sign. Please enter a word.');
        } else {
            setStatus('Please record the sign first before saving.');
        }
    };

    const handleDeleteSign = async (signId: number) => {
        if (!isLoggedIn) {
            showNotification('Please log in to remove custom signs.', 'error');
            return;
        }
        // `removeSign` now handles the API call and refresh internally via context
        await removeSign(signId);
    };

    return (
        <motion.div 
            className="grid md:grid-cols-2 gap-8 items-start"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            {/* Left Column: Training Interface */}
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                aria-live="polite"
            >
                <h2 className="text-3xl font-bold text-cyan-400 mb-6 flex items-center gap-3"><PlusSquareIcon className="w-8 h-8"/> Add a Custom Sign</h2>
                {!isLoggedIn && (
                    <motion.p
                        className="text-yellow-400 text-lg mb-4 p-3 bg-yellow-900/30 rounded-md text-center"
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        role="alert"
                    >
                        Please log in to add and manage your custom signs.
                    </motion.p>
                )}
                <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative flex items-center justify-center mb-4 border border-gray-700">
                    <video ref={videoRef} className={`w-full h-full object-cover ${isCameraOn ? '' : 'hidden'}`} muted aria-label="Webcam feed for recording custom signs" />
                    <AnimatePresence>
                        {!isCameraOn && (
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/80 text-gray-400"
                            >
                                <VideoIcon className="w-16 h-16 mb-4 text-gray-500" aria-hidden="true"/>
                                <p className="text-xl">Camera is off</p>
                            </motion.div>
                        )}
                         {isRecording && (
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                className="absolute top-4 right-4 flex items-center gap-2 bg-red-600/70 text-white px-4 py-2 rounded-full text-base font-semibold"
                            >
                                <span className="relative flex h-3 w-3">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-400"></span>
                                </span>
                                Recording
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
                {cameraError && (
                    <motion.p 
                        className="text-red-400 text-base mt-4 p-3 bg-red-900/30 rounded-md"
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3 }}
                        role="alert"
                    >
                        {cameraError}
                    </motion.p>
                )}
                <div className="space-y-4">
                    <motion.input
                        type="text"
                        value={newSignWord}
                        onChange={(e) => setNewSignWord(e.target.value)}
                        placeholder="Enter word for the new sign"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white text-base focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200"
                        disabled={isRecording || !isLoggedIn}
                        whileFocus={{ scale: 1.01, borderColor: '#06b6d4' }}
                        aria-label="Enter word for new custom sign"
                    />
                    <div className="grid grid-cols-2 gap-4">
                        <motion.button
                            onClick={handleRecord}
                            disabled={isRecording || !newSignWord.trim() || !isLoggedIn}
                            className="py-3 px-4 rounded-lg font-semibold text-white bg-cyan-500 hover:bg-cyan-600 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-3 text-lg"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            aria-label={isRecording ? 'Recording in progress' : `Record sign for ${newSignWord || 'new word'}`}
                        >
                            <CameraIcon className="w-5 h-5"/>
                            {isRecording ? 'Recording...' : 'Record Sign'}
                        </motion.button>
                        <motion.button
                            onClick={handleSave}
                            disabled={isRecording || status !== 'Recording complete! You can now save the sign.' || !newSignWord.trim() || !isLoggedIn}
                            className="py-3 px-4 rounded-lg font-semibold text-white bg-purple-500 hover:bg-purple-600 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-3 text-lg"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            aria-label={`Save sign for ${newSignWord || 'current word'}`}
                        >
                            <SaveIcon className="w-5 h-5"/>
                            Save Sign
                        </motion.button>
                    </div>
                    <motion.p 
                        className="text-center text-cyan-300 h-6 text-base"
                        key={status}
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                        role="status"
                    >
                        {status}
                    </motion.p>
                </div>
            </motion.div>

            {/* Right Column: Custom Signs List */}
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ x: 100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                aria-live="polite"
            >
                <h3 className="text-xl font-bold text-cyan-400 mb-4">Your Custom Signs</h3>
                {!isLoggedIn ? (
                     <p className="text-gray-400 text-base" aria-label="Not logged in for custom signs">Log in to view your custom signs.</p>
                ) : customSigns.length > 0 ? (
                    <motion.ul 
                        className="space-y-3 max-h-96 overflow-y-auto pr-2"
                        initial="hidden"
                        animate="visible"
                        variants={{
                            visible: {
                                transition: {
                                    staggerChildren: 0.05
                                }
                            }
                        }}
                        aria-label="List of custom signs"
                    >
                        <AnimatePresence>
                            {customSigns.map((sign, index) => (
                                <motion.li 
                                    key={sign.id} // Use sign.id as key
                                    className="flex justify-between items-center bg-gray-900/50 p-4 rounded-md border border-gray-700 hover:bg-gray-800/50 transition-colors duration-200"
                                    initial={{ opacity: 0, y: -20, scale: 0.9 }}
                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                    exit={{ opacity: 0, x: 50, transition: { duration: 0.3 } }}
                                    transition={{ duration: 0.3, delay: index * 0.02 }}
                                    aria-label={`Custom sign: ${sign.word}`}
                                >
                                    <span className="text-white font-mono text-lg">{sign.word}</span>
                                    <motion.button 
                                        onClick={() => handleDeleteSign(sign.id)} // Pass sign.id to handler
                                        className="text-red-400 hover:text-red-600 p-1 rounded-full transition-colors"
                                        whileHover={{ scale: 1.2, rotate: 10 }}
                                        whileTap={{ scale: 0.9 }}
                                        aria-label={`Remove custom sign "${sign.word}"`}
                                    >
                                        <TrashIcon className="w-5 h-5" />
                                    </motion.button>
                                </motion.li>
                            ))}
                        </AnimatePresence>
                    </motion.ul>
                ) : (
                    <p className="text-gray-400 text-base" aria-label="No custom signs added">You haven't added any custom signs yet.</p>
                )}
            </motion.div>
        </motion.div>
    );
};

export { CustomSignsPage };