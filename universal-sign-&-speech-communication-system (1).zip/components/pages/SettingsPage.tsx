import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { LanguageContext } from '../../contexts/LanguageContext';
import { AVAILABLE_LANGUAGES } from '../../constants';
import { Language } from '../../types';

// Lucide React Icons (as SVG paths to avoid external dependencies)
const GlobeIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"></circle><line x1="2" x2="22" y1="12" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>);
const KeyIcon: React.FC<{className?: string}> = ({className}) => (<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2L9 3 2 9v9z"></path><path d="M18 10a2 2 0 1 1 0 4A2 2 0 0 1 18 10z"></path></svg>);


const SettingsPage: React.FC = () => {
    const { language, setLanguage } = useContext(LanguageContext);

    const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedLang = AVAILABLE_LANGUAGES.find(lang => lang.code === e.target.value);
        if (selectedLang) {
            setLanguage(selectedLang);
        }
    };

    return (
        <motion.div 
            className="max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <motion.div 
                className="bg-white/5 backdrop-blur-md p-8 rounded-xl border border-white/20 shadow-lg"
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
            >
                <h2 className="text-3xl font-bold text-cyan-400 mb-6 flex items-center gap-3"><GlobeIcon className="w-8 h-8"/> Language Settings</h2> {/* Adjusted gap and mb */}
                <div className="space-y-6">
                    <div>
                        <label htmlFor="language-select" className="block text-xl font-medium text-gray-300 mb-2"> {/* Increased text size */}
                            Preferred Language
                        </label>
                        <p className="text-gray-400 mb-4 text-base"> {/* Increased mb and text size */}
                            Select your preferred language for translated text and speech output across the application.
                        </p>
                        <select
                            id="language-select"
                            value={language.code}
                            onChange={handleLanguageChange}
                            className="w-full bg-gray-700 border border-gray-600 rounded-md p-3 text-white focus:ring-cyan-500 focus:border-cyan-500 text-lg transition-colors duration-200"
                            aria-label="Select preferred language"
                        >
                            {AVAILABLE_LANGUAGES.map((lang: Language) => (
                                <option key={lang.code} value={lang.code}>
                                    {lang.name}
                                </option>
                            ))}
                        </select>
                    </div>
                    <motion.div 
                        className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 flex items-start gap-3" /* Increased p-4 to p-6 */
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        role="note"
                    >
                        <KeyIcon className="w-6 h-6 text-purple-400 flex-shrink-0 mt-1" aria-hidden="true"/>
                        <div>
                            <h3 className="font-semibold text-purple-400 text-xl">API Key Information</h3> {/* Increased text size */}
                            <p className="text-gray-400 mt-1 text-base leading-relaxed"> {/* Increased text size and line height */}
                                Translation and AI services are powered by the Google Gemini API. 
                                The API key for this service is securely managed through environment variables on the server 
                                and is not exposed or configurable directly within the user interface, ensuring enhanced security.
                            </p>
                            <p className="text-gray-500 mt-2 text-sm"> {/* Increased text size */}
                                For more information on Gemini API key management, refer to the official documentation.
                            </p>
                        </div>
                    </motion.div>
                </div>
            </motion.div>
        </motion.div>
    );
};

export { SettingsPage };